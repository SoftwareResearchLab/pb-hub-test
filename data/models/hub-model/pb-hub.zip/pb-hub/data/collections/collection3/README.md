# Collection Name 3

[Add a brief description of the collection here]

## Collection Structure

[Provide an overview of the structure of the collection. Describe the organization of prompts and any sub-collections within the collection.]

### Prompts

[Describe the prompts available in the collection. Highlight their purpose, content, and any relevant details.]

## Usage

[Provide instructions on how to use the prompts from this collection. Include examples or guidelines to help users integrate them into their projects.]

## Contributing

[If applicable, provide guidelines for users who want to contribute to this collection. Include information on how to submit new prompts or suggestions.]

## License

[Specify the license under which this collection is distributed. If applicable, include any additional terms or conditions.]

## Contact

[Provide contact information or links to relevant resources where users can reach out for support or further information.]

